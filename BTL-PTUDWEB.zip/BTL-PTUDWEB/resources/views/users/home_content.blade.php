@extends('layouts.app')
@section('page')
<!-- Page Header-->
<header class="page-header">
  <div class="container-fluid">
    <h2 class="no-margin-bottom">Album Ảnh</h2>
  </div>
</header>
<!-- section -->
<section class="forms">
  <div class="container-fuild" id="container" style="min-height: 400px">

  </div>
</section>
@endsection