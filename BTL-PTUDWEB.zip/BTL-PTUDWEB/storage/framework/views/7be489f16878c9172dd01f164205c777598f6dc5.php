<!--

<?php $__env->startSection('sidebar'); ?>
<nav class="side-navbar">
  <div class="side-navbar-wrapper">
    <div class="sidenav-header d-flex align-items-center justify-content-center">
      <div class="sidenav-header-inner text-center">
        <img src="#" alt="person" class="img-fluid rounded-circle">
        <h2 class="h5 text-uppercase">Name</h2>
        <span class="text-uppercase">Web Developer</span>
      </div>
      <!--<div class="sidenav-header-logo">
        <a href="index.html" class="brand-small text-center"> 
        <strong>B</strong><strong class="text-primary">D</strong></a>
      </div>-->
    <!--</div>
    <div class="main-menu">
      <ul id="side-main-menu" class="side-menu list-unstyled">                  
        <li class="active"><a href="#"> <i class="icon-home"></i><span>Home</span></a></li>
        <li> <a href="#"> <i class="icon-interface-windows"></i><span>Login page</span></a></li>
      </ul>
    </div>
  </div>
</nav>
<?php $__env->stopSection(); ?>-->
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>